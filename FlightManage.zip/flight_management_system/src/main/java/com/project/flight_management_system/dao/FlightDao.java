package com.project.flight_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.flight_management_system.dto.Airhotess;
import com.project.flight_management_system.dto.Flight;
import com.project.flight_management_system.dto.Passenger;
import com.project.flight_management_system.dto.Pilot;
import com.project.flight_management_system.repo.FlightRepo;
@Repository
public class FlightDao {
	@Autowired
	FlightRepo flightRepo;
	@Autowired
	PassengerDao passengerDao;
	@Autowired
	PilotDao pilotDao;
	@Autowired
	AirhotessDao airhotessDao;

	public Flight addExistingPassengerToExistingFlight(int passengerId,int flightId) {
		Flight flight=fetchFlightById(flightId);
		Passenger passenger=passengerDao.fetchPassengerById(passengerId);
		List<Passenger> list = flight.getPassengers();
		list.add(passenger);
		flight.setPassengers(list);
		return flightRepo.save(flight);
	}
	public Flight addExistingPilotToExistingFlight(int flightId,int pilotId) {
		Flight flight =fetchFlightById(flightId);
		Pilot pilot=pilotDao.fetchPilotById(pilotId);
		List<Pilot> list = flight.getPilots();
		list.add(pilot);
		flight.setPilots(list);
		return flightRepo.save(flight);
	}
	public Flight addExistingAirhotessToExistingFlight(int flightId ,int airhotessId) {
		Flight flight=fetchFlightById(flightId);
		Airhotess airhotess=airhotessDao.fetchAirhotessById(airhotessId);
		List<Airhotess> list = flight.getAirhotess();
		list.add(airhotess);
		flight.setAirhotess(list);
		return flightRepo.save(flight);
		
		
	}
	public Flight saveFlight(Flight flight) {
		return flightRepo.save(flight);
	}
	
	public Flight fetchFlightById(int flightId) {
		 Optional<Flight> flight=flightRepo.findById(flightId);
		 if(flight.isPresent()) {
		return flight.get();
		 }else {
			 return null;
		 }
	}
	
	public Flight deleteFlightById(int flightId) {
		Flight flight=fetchFlightById(flightId);
		if(flight!=null) {
		flightRepo.delete(flight);
		return flight;
		}else {
			return null;
		}
	}
	
	public Flight updateFlightById(int oldFlightId ,Flight newFlight) {
		Flight flight = fetchFlightById(oldFlightId);
		if(flight!=null) {
		newFlight.setFlightId(oldFlightId);
		return flightRepo.save(newFlight);
		}else {
			return null;
		}
		
	}
	public List<Flight> fetchAllFlight(){
		return flightRepo.findAll();
	}
}