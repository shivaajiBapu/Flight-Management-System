package com.project.flight_management_system.exception;

public class SeatIdNotFound extends RuntimeException{
	private String message = "Id not Found";

	public String getMessage() {
		return message;
	}
	

}
