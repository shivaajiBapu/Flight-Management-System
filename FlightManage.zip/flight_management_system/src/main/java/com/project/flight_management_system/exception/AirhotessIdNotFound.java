package com.project.flight_management_system.exception;

public class AirhotessIdNotFound extends RuntimeException{
	private String message="Airhotess Id Not Found";

	public String getMessage() {
		return message;
	}
	
}
