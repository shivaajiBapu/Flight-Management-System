package com.project.flight_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.flight_management_system.dto.Address;
import com.project.flight_management_system.dto.Food;
import com.project.flight_management_system.dto.Passenger;
import com.project.flight_management_system.dto.Passport;
import com.project.flight_management_system.dto.Seat;
import com.project.flight_management_system.dto.Ticket;
import com.project.flight_management_system.repo.PassengerRepo;
@Repository
public class PassengerDao {
	@Autowired
	PassengerRepo passengerRepo;
	@Autowired
	AddressDao addressDao;	
	@Autowired
	PassportDao passportDao;
	@Autowired
	SeatDao seatDao;
	@Autowired
	TicketDao ticketDao;
	@Autowired
	FoodDao foodDao;
	public Passenger addNewTicketToExistingPassenger(int passengerId, Ticket newTicket) {
		Passenger passenger=fetchPassengerById(passengerId);
		List<Ticket> list=passenger.getTickets();
		list.add(newTicket);
		passenger.setTickets(list);
		return passengerRepo.save(passenger);
		
	}
	public Passenger addExistingPassengerToExistingAddress(int passengerId,int addressId ) {
		Passenger passenger=fetchPassengerById(passengerId);
		Address address=addressDao.fetchAddressById(addressId);
		passenger.setAddress(address);
		return passengerRepo.save(passenger);
	}  
	public Passenger addExistingPassengerToExistingPassport(int passengerId,int passportId) {
		Passenger passenger=fetchPassengerById(passengerId);
		Passport passport=passportDao.fetchPassportById(passportId);
		passenger.setPassport(passport);
		return passengerRepo.save(passenger);
	}
	public Passenger addExistingSeatToExistingPassenger(int passengerId , int seatId) {
		Passenger passenger=fetchPassengerById(passengerId);
		Seat seat=seatDao.fetchSeatById(seatId);
		passenger.setSeat(seat);
		return passengerRepo.save(passenger);
	}
	public Passenger addNewSeatToExistingPassenger(int passengerId,Seat newSeat){
			Passenger passenger=fetchPassengerById(passengerId);
			passenger.setSeat(newSeat);
			return passengerRepo.save(passenger);
	}
	public Passenger addExistingTicketToExistingPassenger(int passengerId , int ticketId) {
		Passenger passenger=fetchPassengerById(passengerId);
		Ticket ticket=ticketDao.fetchTicketById(ticketId);
		List<Ticket> list=passenger.getTickets();
		list.add(ticket);
		passenger.setTickets(list);
		return passengerRepo.save(passenger);
	}
	public Passenger addExistingFoodToExistingPassenger(int passengerId, int foodId) {
		Passenger passenger=fetchPassengerById(passengerId);
		Food food=foodDao.fetchFoodById(foodId);
		List<Food> list = passenger.getFoods();
		list.add(food);
		passenger.setFoods(list);
		return passengerRepo.save(passenger);
	}
	public Passenger savePassenger(Passenger passenger) {
		return passengerRepo.save(passenger);
	}
	public Passenger fetchPassengerById(int passengerId) {
		Optional<Passenger> passenger=passengerRepo.findById(passengerId);
		 if(passenger.isPresent()) {
			 return passenger.get();
		 }else {
			 return null;
		 }
	}
	public Passenger deletePassengerById(int passengerId) {
		Passenger passenger = fetchPassengerById(passengerId);
		if(passenger!=null) {
		passengerRepo.delete(passenger);
		return passenger;
		}else {
			return null;
		}
	}
	public Passenger updatePassengerById(int oldPassengerId,Passenger newPassenger) {
		Passenger passenger = fetchPassengerById(oldPassengerId);
		if(passenger!=null) {
		newPassenger.setPassengerId(oldPassengerId);
		return passengerRepo.save(newPassenger);
		}else {
			return null;
		}
	}
	public List<Passenger> fetchAllPassenger(){
		return passengerRepo.findAll();
	}
}
