package com.project.flight_management_system.exception;

public class PilotIdNotFound extends RuntimeException{
	private String message = "pilot id not found";

	public String getMessage() {
		return message;
	}
	
}
