package com.project.flight_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.flight_management_system.dto.Airhotess;
import com.project.flight_management_system.service.AirhotessService;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class AirhotessController {
	@Autowired
	AirhotessService airhotessService;
	@Operation(summary = "Save Airhotess", description = "API is used to Save the Airhotess")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Address Saved"),
			@ApiResponse(responseCode = "404", description = "Airhotess not found for the given id") })
	@PostMapping("/saveAirhotess")
	public ResponseStructure<Airhotess> saveAirhotess(@RequestBody Airhotess airhotess) {
		return airhotessService.saveAirhotess(airhotess);
	}
	@Operation(summary = "Fetch Airhotess", description = "API is used to Fetch the Airhotess")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airhotess Fetched"),
			@ApiResponse(responseCode = "404", description = "Airhotess not found for the given id") })
	@GetMapping("/fetchAirhotessById")
	public ResponseStructure<Airhotess> fetchAirhotessById(@RequestParam int airhotessId) {
		return airhotessService.fetchAirhotessById(airhotessId);
	}
	@Operation(summary = "Delete Airhotess", description = "API is used to Deleted the Address")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airhotess Deleted"),
			@ApiResponse(responseCode = "404", description = "Airhotess not found for the given id") })
	@DeleteMapping("/deleteAirhotessById")
	public ResponseStructure<Airhotess> deleteAirhotessById(@RequestParam int airhotessId) {
		return airhotessService.deleteAirhotessById(airhotessId);
	}
	@Operation(summary = "Update Airhotess", description = "API is used to Update the Airhotess")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airhotess Updated"),
			@ApiResponse(responseCode = "404", description = "Airhotess not found for the given id") })
	@PutMapping("/updateAirhotessById")
	public ResponseStructure<Airhotess> updateAirhotessById(@RequestParam int oldAirhotessId,@RequestBody Airhotess newAirhotess) {
		return airhotessService.updateAirhotessById(oldAirhotessId, newAirhotess);
	}
	@Operation(summary = "FetchAll Airhotess", description = "API is used to Fetch All the Airhotess")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airhotess Fetched"),
			@ApiResponse(responseCode = "404", description = "Airhotess not found for the given id") })
	@GetMapping("/fetchAllAirhotess")
	public ResponseStructureAll<Airhotess> fetchAllAirhotess(){
		return airhotessService.fetchAllAirhotess();
}
}