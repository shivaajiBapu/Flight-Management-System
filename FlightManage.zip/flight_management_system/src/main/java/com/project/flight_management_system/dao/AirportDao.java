package com.project.flight_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.flight_management_system.dto.Address;
import com.project.flight_management_system.dto.Airport;
import com.project.flight_management_system.dto.Flight;
import com.project.flight_management_system.repo.AirportRepo;

@Repository
public class AirportDao {
	@Autowired
	AirportRepo airportRepo;
	@Autowired
	AddressDao addressDao;
	@Autowired
	FlightDao flightDao;

	public Airport addExistingAddressToExistingAirport(int airportId, int addressId) {
		Airport airport = fetchAirportById(airportId);
		if (airport != null) {
			Address address = addressDao.fetchAddressById(addressId);
			if (address != null) {
				airport.setAddress(address);
				return airportRepo.save(airport);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public Airport addNewAddressToExistingAirport(int airportId, Address newAddress) {
		Airport airport = fetchAirportById(airportId);
		airport.setAddress(newAddress);
		return airportRepo.save(airport);
	}

	public Airport addExistingFlightToExistingAirport(int airportId, int flightId) {

		Airport airport = fetchAirportById(airportId);
		Flight flight = flightDao.fetchFlightById(flightId);
		List<Flight> list = airport.getFlights();
		list.add(flight);
		airport.setFlights(list);
		return airportRepo.save(airport);
	}

	public Airport addNewFlightToExistingAirport(int airportId, Flight newFlight) {
		Airport airport = fetchAirportById(airportId);
		List<Flight> list = airport.getFlights();
		list.add(newFlight);
		airport.setFlights(list);
		return airportRepo.save(airport);
	}

	public Airport saveAirport(Airport airport) {
		return airportRepo.save(airport);
	}

	public Airport fetchAirportById(int airportId) {
		Optional<Airport> airport = airportRepo.findById(airportId);
		if (airport.isPresent()) {
			return airport.get();
		} else {
			return null;
		}
	}

	public Airport deleteAirportById(int airportId) {
		Airport airport = fetchAirportById(airportId);
		if (airport != null) {
			airportRepo.delete(airport);
			return airport;
		} else {
			return null;
		}
	}

	public Airport updateAirportById(int oldAirPortId, Airport newAirport) {
		Airport airport = fetchAirportById(oldAirPortId);
		if (airport != null) {
			newAirport.setAirportId(oldAirPortId);
			return airportRepo.save(newAirport);
		} else {
			return null;
		}
	}

	public List<Airport> fetchAllAirport() {
		return airportRepo.findAll();
	}
}
