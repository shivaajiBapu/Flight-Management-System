package com.project.flight_management_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.flight_management_system.dao.TicketDao;
import com.project.flight_management_system.dto.Payment;
import com.project.flight_management_system.dto.Ticket;
import com.project.flight_management_system.exception.TicketIdNotFound;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;
@Service
public class TicketService {
	@Autowired
	TicketDao ticketDao;
	@Autowired
	ResponseStructure<Ticket> responseStructure;
	@Autowired
	ResponseStructureAll<Ticket> responseStructureAll;
	public ResponseStructure<Ticket> addExistingPaymentToExistingTicket(int ticketId,int paymentId) {
		responseStructure.setMessage("successfully payment added to ticket in the db");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ticketDao.addExistingPaymentToExistingTicket(ticketId, paymentId));
		return responseStructure;
	}
		
	
	public ResponseStructure<Ticket> addNewPaymentToExistingTicket(int ticketId,Payment newPayment) {
		responseStructure.setMessage("successfully payment added  to ticket in the db");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ticketDao.addNewPaymentToExistingTicket(ticketId, newPayment));
		return responseStructure;
	}
	public ResponseStructure<Ticket> saveTicket(Ticket ticket) {
		responseStructure.setMessage("successfully Seat saved in the db");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(ticketDao.saveTicket(ticket));
		return responseStructure;
	}
	public ResponseStructure<Ticket> fetchTicketById(int ticketId) {
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		if(ticket!=null) {
		responseStructure.setMessage("successfully Seat fetched from the db");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(ticketDao.fetchTicketById(ticketId));
		return responseStructure;
		}else {
			throw new TicketIdNotFound();
		}
	}
	public ResponseStructure<Ticket> deleteTicketById(int ticketId) {
		Ticket ticket = ticketDao.fetchTicketById(ticketId);

		if(ticket!=null) {
		responseStructure.setMessage("successfully ticket deleted db");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ticketDao.deleteTicketById(ticketId));
		return responseStructure;
		}else {
			throw new TicketIdNotFound();
		}
	}
	public ResponseStructure<Ticket> updateTicketById(int oldTicketId,Ticket newTicket) {
			Ticket ticket = ticketDao.fetchTicketById(oldTicketId);
			if(ticket!=null) {
		responseStructure.setMessage("successfully ticket updated in db");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ticketDao.updateTicketById(oldTicketId, newTicket));
		return responseStructure;
			}else {
				throw new TicketIdNotFound();
			}
	}
	public ResponseStructureAll<Ticket> fetchAllTicket(){
		responseStructureAll.setMessage("successfully payment all fetched db");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(ticketDao.fetchAllTicket());
		return responseStructureAll;
	}
}
