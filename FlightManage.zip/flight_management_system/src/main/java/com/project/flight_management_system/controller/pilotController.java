package com.project.flight_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.flight_management_system.dto.Pilot;
import com.project.flight_management_system.service.PilotService;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;
@RestController
public class pilotController {
	@Autowired
	PilotService pilotService;
	@PostMapping("/savePilot")
	public ResponseStructure<Pilot> savePilot(@RequestBody Pilot pilot) {
		return pilotService.savePilot(pilot);
	}
	@GetMapping("/fetchPilotById")
	public ResponseStructure<Pilot> fetchPilotById(@RequestParam int pilotId) {
		return pilotService.fetchPilotById(pilotId);
	}
	@DeleteMapping("/deletePilotById")
	public ResponseStructure<Pilot> deletePilotById(@RequestParam int pilotId) {
		 return pilotService.deletePilotById(pilotId);
	}
	@PutMapping("/updatePilotById")
	public ResponseStructure<Pilot> updatePilotById(@RequestParam int oldPilotId,@RequestBody Pilot newPilotId) {
		return pilotService.updatePilotById(oldPilotId, newPilotId);
	}
	@GetMapping("/fetchAllPilot")
	public ResponseStructureAll<Pilot> fetchAllPilot(){
		return pilotService.fetchAllPilot();
				
	}
}
