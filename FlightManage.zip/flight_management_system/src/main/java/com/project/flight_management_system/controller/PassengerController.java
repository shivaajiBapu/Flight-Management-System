package com.project.flight_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.flight_management_system.dto.Passenger;
import com.project.flight_management_system.dto.Seat;
import com.project.flight_management_system.dto.Ticket;
import com.project.flight_management_system.service.PassengerService;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class PassengerController {
	@Autowired
	PassengerService passengerService;
	@Operation(summary = "addNewTicketToExistingPassenger Passenger", description = "API is used to  add NewTicketToExistingPassenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger created"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addNewTicketToExistingPassenger")
	public ResponseStructure<Passenger> addNewTicketToExistingPassenger(@RequestParam int passengerId,@RequestBody Ticket newTicket) {
		return passengerService.addNewTicketToExistingPassenger(passengerId, newTicket);
	}
	@Operation(summary = "addExistingPassengerToExistingAddress Passenger", description = "API is used to  add aExistingPassengerToExistingAddress")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger added ExistingPassengerToExistingAddress"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addExistingPassengerToExistingAddress")
	public ResponseStructure<Passenger> addExistingPassengerToExistingAddress(@RequestParam int passengerId,@RequestParam int addressId ) {
		return passengerService.addExistingPassengerToExistingAddress(passengerId, addressId);
	}
	@Operation(summary = "addExistingPassengerToExistingPassport Passenger", description = "API is used to  add ExistingPassengerToExistingPassport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger added ExistingPassengerToExistingPassport"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addExistingPassengerToExistingPassport")
	public ResponseStructure<Passenger> addExistingPassengerToExistingPassport(@RequestParam int passengerId,@RequestParam int passportId) {
		return passengerService.addExistingPassengerToExistingPassport(passengerId, passportId);
	}
	@Operation(summary = "addExistingSeatToExistingPassenger Passenger", description = "API is used to  add ExistingSeatToExistingPassenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger added ExistingSeatToExistingPassenger"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addExistingSeatToExistingPassenger")
	public ResponseStructure<Passenger> addExistingSeatToExistingPassenger(@RequestParam int passengerId ,@RequestParam int seatId) {
		return passengerService.addExistingSeatToExistingPassenger(passengerId, seatId);
	}
	@Operation(summary = "addNewSeatToExistingPassenger Passenger", description = "API is used to  add NewSeatToExistingPassenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger added addNewSeatToExistingPassenger"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addNewSeatToExistingPassenger")
	public ResponseStructure<Passenger> addNewSeatToExistingPassenger(@RequestParam int passengerId,@RequestBody Seat newSeat){
		return passengerService.addNewSeatToExistingPassenger(passengerId, newSeat);
	}
	@Operation(summary = "addExistingTicketToExistingPassenger Passenger", description = "API is used to  add ExistingTicketToExistingPassenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger added ExistingTicketToExistingPassenger"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addExistingTicketToExistingPassenger")
	public ResponseStructure<Passenger> addExistingTicketToExistingPassenger(@RequestParam int passengerId ,@RequestParam int ticketId) {
		return passengerService.addExistingTicketToExistingPassenger(passengerId, ticketId);
	}
	@Operation(summary = "addExistingFoodToExistingPassenger Passenger", description = "API is used to  add ExistingFoodToExistingPassenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger added addExistingFoodToExistingPassenger"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/addExistingFoodToExistingPassenger")
	public ResponseStructure<Passenger> addExistingFoodToExistingPassenger(@RequestParam int passengerId,@RequestParam int foodId) {
		return passengerService.addExistingFoodToExistingPassenger(passengerId, foodId);
	}
	@Operation(summary = "savePassenger Passenger", description = "API is used to savePassenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger created"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PostMapping("/savePassenger")
	public ResponseStructure<Passenger> savePassenger(@RequestBody Passenger passenger) {
		return passengerService.savePassenger(passenger);
	}
	@Operation(summary = "Fetch Passenger", description = "API is used to Fetched")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger Fetched"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@GetMapping("/fetchPassengerById")
	public ResponseStructure<Passenger> fetchPassengerById(@RequestParam int passengerId) {
		return passengerService.fetchPassengerById(passengerId);
	}
	@Operation(summary = "deleted Passenger", description = "API is used to Deleted")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger Deleted"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@DeleteMapping("/deletePassengerById")
	public ResponseStructure<Passenger> deletePassengerById(@RequestParam int passengerId) {
		return passengerService.deletePassengerById(passengerId);
	}
	@Operation(summary = "Updated Passenger", description = "API is used to updatePassengerById")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger updated"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@PutMapping("/updatePassengerById")
	public ResponseStructure<Passenger> updatePassengerById(@RequestParam int oldPassengerId,@RequestBody Passenger newPassenger) {
		return passengerService.updatePassengerById(oldPassengerId, newPassenger);
		
	}
	@Operation(summary = "fetchAll Passenger", description = "API is used to fetchAll Passenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Passenger fetchAll"),
			@ApiResponse(responseCode = "404", description = "Passenger not found for the given id") })
	@GetMapping("/fetchAllPassenger")
	public ResponseStructureAll<Passenger> fetchAllPassenger(){
		return passengerService.fetchAllPassenger();
				
	}
}
