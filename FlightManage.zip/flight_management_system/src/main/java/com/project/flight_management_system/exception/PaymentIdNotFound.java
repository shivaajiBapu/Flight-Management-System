package com.project.flight_management_system.exception;

public class PaymentIdNotFound extends RuntimeException{
	private String message = "Id not found";

	public String getMessage() {
		return message;
	}
	
}
