package com.project.flight_management_system.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Airhotess {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int airhotessId;
	private String airhotessName;
	private double airhotessSalary;
	private int airhotessAge;
	private long airhotessPhone;
	
	public int getAirhotessId() {
		return airhotessId;
	}
	public void setAirhotessId(int airhotessId) {
		this.airhotessId = airhotessId;
	}
	public String getAirhotessName() {
		return airhotessName;
	}
	public void setAirhotessName(String airhotessName) {
		this.airhotessName = airhotessName;
	}
	public double getAirhotessSalary() {
		return airhotessSalary;
	}
	public void setAirhotessSalary(double airhotessSalary) {
		this.airhotessSalary = airhotessSalary;
	}
	public int getAirhotessAge() {
		return airhotessAge;
	}
	public void setAirhotessAge(int airhotessAge) {
		this.airhotessAge = airhotessAge;
	}
	public long getAirhotessPhone() {
		return airhotessPhone;
	}
	public void setAirhotessPhone(long airhotessPhone) {
		this.airhotessPhone = airhotessPhone;
	}
	
	
}
