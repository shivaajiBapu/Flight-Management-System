package com.project.flight_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.flight_management_system.dto.Address;
import com.project.flight_management_system.dto.Airport;
import com.project.flight_management_system.dto.Flight;
import com.project.flight_management_system.service.AirportService;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class AirportController {
	@Autowired
	AirportService airportService;
	@Operation(summary = "addExistingAddressToExistingAirport Airport", description = "API is used to addExistingAddressToExistingAirport ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added ExistingAddressToExistingAirport"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PutMapping("/addExistingAddressToExistingAirport")
	public ResponseStructure<Airport> addExistingAddressToExistingAirport(@RequestParam int airportId,@RequestParam int addressId) {
		return airportService.addExistingAddressToExistingAirport(airportId, addressId);
	}
	@Operation(summary = "addNewAddressToExistingAirport Airport", description = "API is used to addNewAddressToExistingAirport ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added NewAddressToExistingAirport"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PutMapping("/addNewAddressToExistingAirport")
	public ResponseStructure<Airport> addNewAddressToExistingAirport(@RequestParam int airportId,@RequestBody Address newAddress) {
		return airportService.addNewAddressToExistingAirport(airportId, newAddress);
	}
	@Operation(summary = "addExistingFlightToExistingAirport Airport", description = "API is used to addExistingFlightToExistingAirport ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added ExistingFlightToExistingAirport"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PutMapping("/addExistingFlightToExistingAirport")
	public ResponseStructure<Airport> addExistingFlightToExistingAirport(@RequestParam int airportId,@RequestParam int flightId) {
		return airportService.addExistingFlightToExistingAirport(airportId, flightId);
	}
	@Operation(summary = "addNewFlightToExistingAirport Airport", description = "API is used to addNewFlightToExistingAirport ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added NewFlightToExistingAirport"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PutMapping("/addNewFlightToExistingAirport")
	public ResponseStructure<Airport> addNewFlightToExistingAirport(@RequestParam int airportId,@RequestBody Flight newFlight) {
		 return airportService.addNewFlightToExistingAirport(airportId, newFlight);
		}
	@Operation(summary = "Save Airport", description = "API is used to save the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airport created"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PostMapping("/saveAirport")
	public ResponseStructure<Airport> saveAirport(@RequestBody Airport airport) {
		return airportService.saveAirport(airport);
	}
	@Operation(summary = "Fetch Airport", description = "API is used to Fetch the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airport Fetched"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@GetMapping("/fetchAirportById")
	public ResponseStructure<Airport> fetchAirportById(@RequestParam int airportId) {
		return airportService.fetchAirportById(airportId);
	}
	@Operation(summary = "Delete Airport", description = "API is used to Delete the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airport Deleted"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@DeleteMapping("/deleteAirportById")
	public ResponseStructure<Airport> deleteAirportById(@RequestParam int airportId) {
		return airportService.deleteAirportById(airportId);
	}
	@Operation(summary = "Update Airport", description = "API is used to Update the Address")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Airport Updated"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PutMapping("/updateAirportById")
	public ResponseStructure<Airport> updateAirportById(@RequestParam int oldAirPortId ,@RequestBody Airport newAirport) {
		return airportService.updateAirportById(oldAirPortId, newAirport);
	
	}
	@Operation(summary = "FetchAll Airport", description = "API is used to Update the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully All Airport Fetched"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@GetMapping("/fetchAllAirport")
	public ResponseStructureAll<Airport> fetchAllAirport() {
		return airportService.fetchAllAirport();
	}
}
