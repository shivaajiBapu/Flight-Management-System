package com.project.flight_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.flight_management_system.dao.PassengerDao;
import com.project.flight_management_system.dto.Passenger;
import com.project.flight_management_system.dto.Seat;
import com.project.flight_management_system.dto.Ticket;
import com.project.flight_management_system.exception.PassengerIdNotFound;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;
@Service
public class PassengerService {
	@Autowired
	PassengerDao passengerDao;
	@Autowired
	ResponseStructure<Passenger> responseStructure;
	@Autowired
	ResponseStructureAll<Passenger> responseStructureAll;
	
	public ResponseStructure<Passenger> addNewTicketToExistingPassenger(int passengerId, Ticket newTicket) {
		responseStructure.setMessage("successfully new ticket added in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addNewTicketToExistingPassenger(passengerId, newTicket));
		return responseStructure; 
	}
	
	public ResponseStructure<Passenger> addExistingPassengerToExistingAddress(int passengerId,int addressId ) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingPassengerToExistingAddress(passengerId, addressId));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> addExistingPassengerToExistingPassport(int passengerId,int passportId) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingPassengerToExistingPassport(passengerId, passportId));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> addExistingSeatToExistingPassenger(int passengerId , int seatId) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingSeatToExistingPassenger(passengerId, seatId));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> addNewSeatToExistingPassenger(int passengerId,Seat newSeat){
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addNewSeatToExistingPassenger(passengerId, newSeat));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> addExistingTicketToExistingPassenger(int passengerId , int ticketId) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingTicketToExistingPassenger(passengerId, ticketId));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> addExistingFoodToExistingPassenger(int passengerId, int foodId) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingFoodToExistingPassenger(passengerId, foodId));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> savePassenger(Passenger passenger) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(passengerDao.savePassenger(passenger));
		return responseStructure; 
	}
	public ResponseStructure<Passenger> fetchPassengerById(int passengerId) {
		Passenger passenger=passengerDao.fetchPassengerById(passengerId);
		if(passenger!=null) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(passengerDao.fetchPassengerById(passengerId));
		return responseStructure; 
		}else {
			throw new PassengerIdNotFound();
		}
	}
	public ResponseStructure<Passenger> deletePassengerById(int passengerId) {
		Passenger passenger = passengerDao.fetchPassengerById(passengerId);
		if(passenger!=null) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.deletePassengerById(passengerId));
		return responseStructure;
		}else {
			throw new PassengerIdNotFound();
		}
	}
	public ResponseStructure<Passenger> updatePassengerById(int oldPassengerId,Passenger newPassenger) {
		Passenger passenger = passengerDao.fetchPassengerById(oldPassengerId);
		if(passenger!=null) {
		responseStructure.setMessage("successfully passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData( passengerDao.updatePassengerById(oldPassengerId, newPassenger));
		return responseStructure;
		}else {
			throw new PassengerIdNotFound();
		}
	}
	public ResponseStructureAll<Passenger> fetchAllPassenger(){
		responseStructureAll.setMessage("successfully passenger saved in the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(passengerDao.fetchAllPassenger());
		return responseStructureAll;
				
	}
}
