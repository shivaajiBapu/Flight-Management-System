package com.project.flight_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.flight_management_system.dto.Airhotess;
import com.project.flight_management_system.repo.AirhotessRepo;
@Repository
public class AirhotessDao {
	@Autowired
	AirhotessRepo airhotessRepo;
	
	public Airhotess saveAirhotess(Airhotess airhotess) {
		return airhotessRepo.save(airhotess);
	}
	public Airhotess fetchAirhotessById(int airhotessId) {
		Optional<Airhotess> airhotess = airhotessRepo.findById(airhotessId);
		if(airhotess.isPresent()) {
			return airhotess.get();
		}else {
			return null;
		}
	}
	public Airhotess deleteAirhotessById(int airhotessId) {
		Airhotess airhotess=fetchAirhotessById(airhotessId);
		if(airhotess!=null) {
		airhotessRepo.delete(airhotess);
		return airhotess;
		}else {
			return null;
		}
	}
	public Airhotess updateAirhotessById(int oldAirhotessId,Airhotess newAirhotess) {
		Airhotess airhotess = fetchAirhotessById(oldAirhotessId);
		if(airhotess!=null) {
		newAirhotess.setAirhotessId(oldAirhotessId);
		return airhotessRepo.save(newAirhotess);
		}else {
			return null;
		}
	}
	public List<Airhotess> fetchAllAirhotess(){
		return airhotessRepo.findAll();
	}
}
