package com.project.flight_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.flight_management_system.dao.AirhotessDao;
import com.project.flight_management_system.dto.Airhotess;
import com.project.flight_management_system.exception.AirhotessIdNotFound;
import com.project.flight_management_system.exception.AirportIdNotFound;
import com.project.flight_management_system.repo.AirhotessRepo;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;
@Service
public class AirhotessService {
	@Autowired
	AirhotessDao airhotessDao;
	@Autowired
	ResponseStructure<Airhotess> responseStructure;
	@Autowired
	ResponseStructureAll<Airhotess> responseStructureAll;
	@Autowired
	AirhotessRepo airhotessRepo;
	
	public ResponseStructure<Airhotess> saveAirhotess(Airhotess airhotess) {
		responseStructure.setMessage("successfully airhotess saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(airhotessDao.saveAirhotess(airhotess));
		return responseStructure;
	}
	public ResponseStructure<Airhotess> fetchAirhotessById(int airhotessId) {
		 Airhotess airhotess=airhotessDao.fetchAirhotessById(airhotessId);
		if(airhotess!=null) {
		responseStructure.setMessage("successfully airhotess fetched from the DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(airhotessDao.fetchAirhotessById(airhotessId));
		return responseStructure;
		}else {
			throw new AirhotessIdNotFound();
		}
	}
	public ResponseStructure<Airhotess> deleteAirhotessById(int airhotessId) {
		 Airhotess airhotess=airhotessDao.fetchAirhotessById(airhotessId);
		 if(airhotess!=null) {
		responseStructure.setMessage("successfully airhotess deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(airhotessDao.deleteAirhotessById(airhotessId));
		return responseStructure;
		 }else {
			 throw new AirhotessIdNotFound();
		 }
	}
	public ResponseStructure<Airhotess> updateAirhotessById(int oldAirhotessId,Airhotess newAirhotess) {
		 Airhotess airhotess=airhotessDao.fetchAirhotessById(oldAirhotessId);
		 if(airhotess!=null) {
		responseStructure.setMessage("successfully airhotess updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(airhotessDao.updateAirhotessById(oldAirhotessId, newAirhotess));
		return responseStructure;
		 }else {
			 throw new AirhotessIdNotFound();
			 
		 }
	}
	public ResponseStructureAll<Airhotess> fetchAllAirhotess(){
		responseStructureAll.setMessage("successfully airhotess all fetched from the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(airhotessDao.fetchAllAirhotess());
		return responseStructureAll;
}
}