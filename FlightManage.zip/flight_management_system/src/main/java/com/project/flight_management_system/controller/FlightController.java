package com.project.flight_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.flight_management_system.dto.Flight;
import com.project.flight_management_system.service.FlightService;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class FlightController {
	@Autowired
	FlightService flightService;
	@Operation(summary = "addExistingPassengerToExistingFlight Flight", description = "API is used to add ExistingPassengerToExistingFlight ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added ExistingPassengerToExistingFlight"),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@PutMapping("/addExistingPassengerToExistingFlight")
	public ResponseStructure<Flight> addExistingPassengerToExistingFlight(@RequestParam int passengerId,@RequestParam int flightId) {
	return flightService.addExistingPassengerToExistingFlight(passengerId, flightId);
	}
	@Operation(summary = "addExistingPassengerToExistingFlight Flight", description = "API is used to add ExistingPassengerToExistingFlight ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added ExistingPassengerToExistingFlight"),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@PutMapping("/addExistingPilotToExistingFlight")
	public ResponseStructure<Flight> addExistingPilotToExistingFlight(@RequestParam int flightId,@RequestParam int pilotId) {
		return flightService.addExistingPilotToExistingFlight(flightId, pilotId);
	}
	@Operation(summary = "addExistingAirhotessToExistingFlight Flight", description = "API is used to add ExistingAirhotessToExistingFlight ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully added addExistingAirhotessToExistingFlight"),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@PutMapping("/addExistingAirhotessToExistingFlight")
	public ResponseStructure<Flight> addExistingAirhotessToExistingFlight(@RequestParam int flightId ,@RequestParam int airhotessId) {
		return flightService.addExistingAirhotessToExistingFlight(flightId, airhotessId);
	}
	@Operation(summary = "Save Flight", description = "API is used to save the Flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Flight created"),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@PostMapping("/saveFlight")
	public ResponseStructure<Flight> saveFlight(@RequestBody Flight flight) {
		return flightService.saveFlight(flight);
	}
	@Operation(summary = "Fetch Flight", description = "API is used to Fetch the Flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Flight Fetched "),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@GetMapping("/fetchFlightById")
	public ResponseStructure<Flight> fetchFlightById(@RequestParam int flightId) {
		return flightService.fetchFlightById(flightId);
	}
	@Operation(summary = "Delete Flight", description = "API is used to Delete the Flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Flight Delete "),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@DeleteMapping("/deleteFlightById")
	public ResponseStructure<Flight> deleteFlightById(@RequestParam int flightId) {
		return flightService.deleteFlightById(flightId);
	}
	@Operation(summary = "Update Flight", description = "API is used to Update the Flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Flight Updated "),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@PutMapping("/updateFlightById")
	public ResponseStructure<Flight> updateFlightById(@RequestParam int oldFlightId ,@RequestBody Flight newFlight) {
		return flightService.updateFlightById(oldFlightId, newFlight);
		
	}
	@Operation(summary = "FetchAll Flight", description = "API is used to FetchAll the Flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully Flight FetchAll "),
			@ApiResponse(responseCode = "404", description = "Flight not found for the given id") })
	@GetMapping("/fetchAllFlight")
	public ResponseStructureAll<Flight> fetchAllFlight(){
		return flightService.fetchAllFlight();
	}
}
