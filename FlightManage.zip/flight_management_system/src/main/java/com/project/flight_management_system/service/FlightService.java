package com.project.flight_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.flight_management_system.dao.FlightDao;
import com.project.flight_management_system.dto.Flight;
import com.project.flight_management_system.exception.FlightIdNotFound;
import com.project.flight_management_system.util.ResponseStructure;
import com.project.flight_management_system.util.ResponseStructureAll;
@Service
public class FlightService {
	@Autowired
	FlightDao  flightDao;
	@Autowired
	ResponseStructure<Flight> responseStructure;
	@Autowired
	ResponseStructureAll<Flight> responseStructureAll;
	
	public ResponseStructure<Flight> addExistingPassengerToExistingFlight(int passengerId,int flightId) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addExistingPassengerToExistingFlight(passengerId, flightId));
		return responseStructure;
	}
	public ResponseStructure<Flight> addExistingPilotToExistingFlight(int flightId,int pilotId) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addExistingPilotToExistingFlight(flightId, pilotId));
		return responseStructure;
	}
	public ResponseStructure<Flight> addExistingAirhotessToExistingFlight(int flightId ,int airhotessId) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addExistingAirhotessToExistingFlight(flightId, airhotessId));
		return responseStructure;
		}
	public ResponseStructure<Flight> saveFlight(Flight flight) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(flightDao.saveFlight(flight));
		return responseStructure;
	}
	
	public ResponseStructure<Flight> fetchFlightById(int flightId) {
		Flight flight=flightDao.fetchFlightById(flightId);
		if(flight!=null) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(flightDao.fetchFlightById(flightId));
		return responseStructure;
		}else {
			throw new FlightIdNotFound();
		}
	}
	
	public ResponseStructure<Flight> deleteFlightById(int flightId) {
		 Flight flight=flightDao.fetchFlightById(flightId);
		 if(flight!=null) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.deleteFlightById(flightId));
		return responseStructure;
		 }else {
			 throw new FlightIdNotFound();
		 }
	}
	
	public ResponseStructure<Flight> updateFlightById(int oldFlightId ,Flight newFlight) {
		 Flight flight=flightDao.fetchFlightById(oldFlightId);
		 if(flight!=null) {
		responseStructure.setMessage("successfully address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.updateFlightById(oldFlightId, newFlight));
		return responseStructure;
		 }else {
			 throw new FlightIdNotFound();
		 }
	}
	public ResponseStructureAll<Flight> fetchAllFlight(){
		responseStructureAll.setMessage("successfully address saved in the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(flightDao.fetchAllFlight());
		return responseStructureAll;
	}
}
