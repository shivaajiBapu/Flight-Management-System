package com.project.flight_management_system.exception;

public class PassportIdNotFound extends RuntimeException{
	private String message = "Id Not Found";

	public String getMessage() {
		return message;
	}
	
}
